const DarkModeTheme = {
    primaryBg: '#000000',
    secondaryBg: '#14213d',
    accent: '#fca311',
    secondaryText: '#e5e5e5',
    primaryText: '#ffffff',
    faded: '#ffffff33'
}

export default DarkModeTheme;