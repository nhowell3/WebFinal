const LightModeTheme = {
    primaryBg: '#e5e5e5',
    secondaryBg: '#ffffff',
    accent: '#fca311',
    secondaryText: '#14213d',
    primaryText: '#000000',
    faded: '#000000AA'
}

export default LightModeTheme;