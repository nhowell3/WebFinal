export default function PageContentDiv({children}){
    return (
        <div className="mt-8 px-8">
            {children}
        </div>
    );
}